// UrbanRisk Mont-Ngafula – suivi satellite des inondations et de l'érosion
// BEGCED « De la donnée à l'action » – version 1.0 du 27/10/2026
// Chaque ouverture recalcule avec les dernières images Sentinel-1 et Sentinel-2 disponibles.

var COMMUNE = ee.Geometry.Polygon([[[15.1298,-4.4445],[15.1332,-4.4445],[15.1380,-4.4458],[15.1407,-4.4449],[15.1428,-4.4471],[15.1437,-4.4494],[15.1451,-4.4511],[15.1470,-4.4524],[15.1519,-4.4529],[15.1540,-4.4518],[15.1548,-4.4522],[15.1555,-4.4533],[15.1623,-4.4557],[15.1645,-4.4600],[15.1658,-4.4614],[15.1668,-4.4644],[15.1711,-4.4705],[15.1740,-4.4783],[15.1741,-4.4844],[15.1767,-4.4896],[15.1754,-4.4943],[15.1760,-4.4968],[15.1757,-4.4980],[15.1746,-4.4995],[15.1736,-4.5032],[15.1741,-4.5059],[15.1763,-4.5077],[15.1776,-4.5112],[15.1776,-4.5141],[15.1768,-4.5162],[15.1737,-4.5205],[15.1731,-4.5246],[15.1723,-4.5268],[15.1723,-4.5320],[15.1737,-4.5331],[15.1772,-4.5342],[15.1797,-4.5338],[15.1998,-4.5350],[15.2072,-4.5364],[15.2106,-4.5353],[15.2133,-4.5364],[15.2149,-4.5381],[15.2172,-4.5395],[15.2205,-4.5399],[15.2198,-4.5405],[15.2250,-4.5441],[15.2273,-4.5464],[15.2277,-4.5487],[15.2286,-4.5503],[15.2334,-4.5551],[15.2362,-4.5561],[15.2388,-4.5579],[15.2407,-4.5605],[15.2460,-4.5648],[15.2517,-4.5656],[15.2548,-4.5668],[15.2609,-4.5726],[15.2635,-4.5727],[15.2649,-4.5742],[15.2646,-4.5829],[15.2622,-4.5891],[15.2655,-4.5906],[15.2668,-4.5924],[15.2666,-4.6000],[15.2669,-4.6021],[15.2678,-4.6043],[15.2729,-4.6107],[15.2777,-4.6131],[15.2865,-4.6216],[15.2892,-4.6215],[15.2919,-4.6208],[15.2923,-4.6214],[15.2933,-4.6216],[15.2962,-4.6217],[15.2963,-4.6223],[15.2969,-4.6223],[15.3008,-4.6213],[15.3014,-4.6207],[15.3014,-4.6219],[15.3020,-4.6221],[15.3020,-4.6227],[15.3035,-4.6226],[15.3036,-4.6230],[15.3043,-4.6232],[15.3042,-4.6237],[15.3055,-4.6244],[15.3106,-4.6241],[15.3115,-4.6235],[15.3119,-4.6239],[15.3130,-4.6235],[15.3150,-4.6246],[15.3152,-4.6243],[15.3173,-4.6277],[15.3176,-4.6273],[15.3196,-4.6291],[15.3201,-4.6287],[15.3204,-4.6299],[15.3209,-4.6300],[15.3220,-4.6316],[15.3219,-4.6327],[15.3234,-4.6322],[15.3245,-4.6329],[15.3249,-4.6323],[15.3263,-4.6325],[15.3269,-4.6319],[15.3273,-4.6321],[15.3276,-4.6363],[15.3288,-4.6373],[15.3299,-4.6373],[15.3299,-4.6388],[15.3308,-4.6392],[15.3293,-4.6424],[15.3297,-4.6428],[15.3296,-4.6437],[15.3312,-4.6448],[15.3316,-4.6459],[15.3327,-4.6462],[15.3345,-4.6457],[15.3354,-4.6468],[15.3366,-4.6463],[15.3373,-4.6466],[15.3380,-4.6460],[15.3386,-4.6466],[15.3399,-4.6463],[15.3404,-4.6457],[15.3412,-4.6459],[15.3414,-4.6452],[15.3427,-4.6460],[15.3440,-4.6459],[15.3439,-4.6470],[15.3451,-4.6469],[15.3453,-4.6478],[15.3491,-4.6477],[15.3506,-4.6489],[15.3510,-4.6485],[15.3515,-4.6489],[15.3527,-4.6485],[15.3524,-4.6477],[15.3538,-4.6470],[15.3540,-4.6463],[15.3579,-4.6465],[15.3577,-4.6432],[15.3585,-4.6427],[15.3600,-4.6427],[15.3589,-4.6439],[15.3591,-4.6444],[15.3620,-4.6440],[15.3630,-4.6423],[15.3648,-4.6412],[15.3662,-4.6411],[15.3680,-4.6398],[15.3688,-4.6374],[15.3710,-4.6371],[15.3738,-4.6386],[15.3758,-4.6366],[15.3765,-4.6376],[15.3783,-4.6374],[15.3776,-4.6337],[15.3814,-4.6317],[15.3829,-4.6289],[15.3852,-4.6287],[15.3868,-4.6258],[15.3904,-4.6247],[15.3897,-4.6230],[15.3908,-4.6206],[15.3923,-4.6192],[15.3924,-4.6184],[15.3911,-4.6171],[15.3926,-4.6132],[15.3941,-4.6112],[15.3969,-4.6103],[15.3976,-4.6049],[15.3997,-4.6032],[15.4006,-4.6019],[15.4037,-4.6009],[15.4036,-4.5982],[15.4057,-4.5926],[15.4044,-4.5895],[15.4070,-4.5888],[15.4084,-4.5880],[15.4080,-4.5861],[15.4059,-4.5835],[15.4063,-4.5824],[15.4078,-4.5823],[15.4078,-4.5820],[15.4069,-4.5813],[15.4050,-4.5780],[15.4066,-4.5730],[15.4059,-4.5718],[15.4061,-4.5711],[15.4044,-4.5666],[15.4045,-4.5661],[15.4066,-4.5648],[15.4067,-4.5642],[15.4053,-4.5614],[15.4032,-4.5602],[15.4073,-4.5541],[15.4054,-4.5529],[15.4001,-4.5547],[15.3992,-4.5541],[15.3984,-4.5516],[15.3950,-4.5510],[15.3947,-4.5476],[15.3910,-4.5479],[15.3910,-4.5444],[15.3891,-4.5451],[15.3903,-4.5424],[15.3896,-4.5405],[15.3891,-4.5401],[15.3855,-4.5405],[15.3837,-4.5396],[15.3823,-4.5398],[15.3824,-4.5340],[15.3819,-4.5328],[15.3810,-4.5314],[15.3798,-4.5319],[15.3786,-4.5304],[15.3757,-4.5293],[15.3753,-4.5284],[15.3753,-4.5225],[15.3746,-4.5171],[15.3720,-4.5156],[15.3687,-4.5153],[15.3672,-4.5137],[15.3667,-4.5115],[15.3671,-4.5102],[15.3694,-4.5074],[15.3694,-4.5051],[15.3671,-4.5042],[15.3645,-4.5040],[15.3600,-4.5023],[15.3595,-4.5017],[15.3599,-4.4934],[15.3606,-4.4922],[15.3604,-4.4915],[15.3572,-4.4882],[15.3560,-4.4888],[15.3552,-4.4889],[15.3548,-4.4884],[15.3565,-4.4852],[15.3546,-4.4845],[15.3547,-4.4831],[15.3537,-4.4827],[15.3532,-4.4802],[15.3505,-4.4789],[15.3500,-4.4763],[15.3492,-4.4747],[15.3507,-4.4733],[15.3508,-4.4704],[15.3523,-4.4688],[15.3545,-4.4642],[15.3558,-4.4633],[15.3556,-4.4616],[15.3535,-4.4609],[15.3530,-4.4586],[15.3524,-4.4580],[15.3544,-4.4546],[15.3543,-4.4535],[15.3527,-4.4520],[15.3525,-4.4512],[15.3552,-4.4499],[15.3582,-4.4501],[15.3598,-4.4487],[15.3601,-4.4474],[15.3593,-4.4463],[15.3581,-4.4461],[15.3568,-4.4470],[15.3563,-4.4468],[15.3574,-4.4458],[15.3590,-4.4422],[15.3608,-4.4415],[15.3607,-4.4405],[15.3592,-4.4394],[15.3596,-4.4381],[15.3587,-4.4382],[15.3576,-4.4391],[15.3563,-4.4391],[15.3553,-4.4399],[15.3535,-4.4401],[15.3510,-4.4376],[15.3424,-4.4352],[15.3416,-4.4356],[15.3382,-4.4337],[15.3364,-4.4305],[15.3352,-4.4296],[15.3350,-4.4284],[15.3325,-4.4275],[15.3315,-4.4260],[15.3304,-4.4257],[15.3288,-4.4259],[15.3258,-4.4288],[15.3245,-4.4294],[15.3203,-4.4290],[15.3189,-4.4283],[15.3167,-4.4288],[15.3163,-4.4300],[15.3125,-4.4306],[15.3125,-4.4326],[15.3116,-4.4338],[15.3102,-4.4340],[15.3100,-4.4344],[15.3074,-4.4341],[15.3075,-4.4324],[15.3067,-4.4324],[15.3067,-4.4301],[15.3082,-4.4280],[15.3086,-4.4262],[15.3076,-4.4207],[15.3021,-4.4122],[15.3017,-4.4083],[15.3039,-4.4030],[15.3080,-4.3972],[15.3077,-4.3954],[15.3048,-4.3982],[15.2982,-4.4006],[15.2951,-4.4039],[15.2900,-4.4082],[15.2761,-4.4374],[15.2748,-4.4381],[15.2717,-4.4381],[15.2657,-4.4412],[15.2586,-4.4419],[15.2567,-4.4402],[15.2579,-4.4369],[15.2580,-4.4338],[15.2494,-4.4337],[15.2475,-4.4327],[15.2456,-4.4329],[15.2449,-4.4320],[15.2435,-4.4320],[15.2429,-4.4314],[15.2419,-4.4320],[15.2417,-4.4313],[15.2394,-4.4316],[15.2389,-4.4307],[15.2356,-4.4286],[15.2346,-4.4272],[15.2339,-4.4256],[15.2337,-4.4214],[15.2305,-4.4202],[15.2279,-4.4179],[15.2277,-4.4154],[15.2262,-4.4120],[15.2264,-4.4101],[15.2251,-4.4085],[15.2233,-4.4031],[15.2239,-4.4006],[15.2229,-4.3992],[15.2234,-4.3948],[15.2229,-4.3930],[15.2235,-4.3916],[15.2230,-4.3895],[15.2232,-4.3878],[15.2222,-4.3840],[15.2176,-4.3774],[15.2148,-4.3708],[15.2137,-4.3693],[15.2133,-4.3671],[15.2136,-4.3664],[15.2137,-4.3621],[15.2132,-4.3612],[15.2124,-4.3608],[15.2119,-4.3589],[15.2093,-4.3561],[15.2105,-4.3547],[15.2114,-4.3514],[15.2111,-4.3505],[15.2087,-4.3478],[15.2077,-4.3478],[15.2056,-4.3458],[15.2034,-4.3455],[15.1994,-4.3432],[15.1983,-4.3431],[15.1961,-4.3414],[15.1904,-4.3398],[15.1885,-4.3408],[15.1874,-4.3434],[15.1879,-4.3473],[15.1874,-4.3502],[15.1879,-4.3519],[15.1875,-4.3537],[15.1869,-4.3541],[15.1871,-4.3550],[15.1859,-4.3560],[15.1866,-4.3561],[15.1865,-4.3566],[15.1854,-4.3579],[15.1848,-4.3579],[15.1840,-4.3594],[15.1843,-4.3608],[15.1850,-4.3604],[15.1855,-4.3608],[15.1847,-4.3666],[15.1830,-4.3679],[15.1809,-4.3674],[15.1784,-4.3679],[15.1776,-4.3693],[15.1772,-4.3715],[15.1775,-4.3754],[15.1771,-4.3781],[15.1783,-4.3813],[15.1784,-4.3837],[15.1794,-4.3849],[15.1793,-4.3858],[15.1807,-4.3883],[15.1827,-4.3880],[15.1818,-4.3889],[15.1825,-4.3897],[15.1824,-4.3903],[15.1791,-4.3902],[15.1779,-4.3918],[15.1757,-4.3929],[15.1750,-4.3939],[15.1747,-4.3948],[15.1758,-4.3967],[15.1754,-4.3971],[15.1701,-4.3978],[15.1674,-4.3997],[15.1660,-4.4017],[15.1649,-4.4025],[15.1645,-4.4023],[15.1639,-4.4032],[15.1638,-4.4046],[15.1624,-4.4051],[15.1612,-4.4065],[15.1625,-4.4105],[15.1621,-4.4108],[15.1611,-4.4090],[15.1601,-4.4082],[15.1570,-4.4098],[15.1569,-4.4126],[15.1551,-4.4130],[15.1548,-4.4126],[15.1520,-4.4134],[15.1513,-4.4154],[15.1505,-4.4155],[15.1502,-4.4149],[15.1495,-4.4162],[15.1489,-4.4158],[15.1491,-4.4153],[15.1486,-4.4163],[15.1474,-4.4168],[15.1443,-4.4217],[15.1443,-4.4239],[15.1432,-4.4250],[15.1436,-4.4256],[15.1413,-4.4261],[15.1404,-4.4269],[15.1387,-4.4314],[15.1388,-4.4348],[15.1344,-4.4365],[15.1350,-4.4396],[15.1313,-4.4408],[15.1310,-4.4405],[15.1308,-4.4416],[15.1298,-4.4429],[15.1298,-4.4445]]]);   // OpenStreetMap, relation 389761
var ZONE = COMMUNE.buffer(500);
var NOW = ee.Date(Date.now());
var REF_DEBUT = '2023-01-01';

// ---------- Paramètres (documentés, à calibrer avec le terrain) ----------
var P = {
  eauVV: -18,        // dB : seuil de rétrodiffusion VV de l'eau libre
  baisse: 3,         // dB : baisse minimale par rapport à la référence sèche
  penteMaxEau: 5,    // degrés
  handMaxEau: 15,    // m au-dessus du cours d'eau le plus proche (MERIT Hydro)
  eauPermanente: 50, // % d'occurrence JRC au-delà duquel l'eau est permanente
  ndviAvant: 0.35,   // végétation avant
  ndviApres: 0.20,   // sol devenu nu
  bsiApres: 0.05,    // indice de sol nu
  penteMinErosion: 8,// degrés
  pixelsMin: 6       // taille minimale d'une tache (pixels de 10 m)
};

// ---------- Données fixes ----------
var dem = ee.ImageCollection('COPERNICUS/DEM/GLO30').filterBounds(ZONE).select('DEM').mosaic()
  .setDefaultProjection('EPSG:4326', null, 30);
var pente = ee.Terrain.slope(dem);
var hand = ee.Image('MERIT/Hydro/v1_0_1').select('hnd');
var gsw = ee.Image('JRC/GSW1_4/GlobalSurfaceWater').select('occurrence').unmask(0);
var batiments = ee.FeatureCollection('GOOGLE/Research/open-buildings/v3/polygons')
  .filterBounds(COMMUNE).filter(ee.Filter.gte('confidence', 0.70));

// ---------- Inondation : Sentinel-1 (radar) ----------
var s1 = ee.ImageCollection('COPERNICUS/S1_GRD').filterBounds(COMMUNE)
  .filter(ee.Filter.eq('instrumentMode', 'IW'))
  .filter(ee.Filter.listContains('transmitterReceiverPolarisation', 'VV'))
  .select('VV');
var s1Dernier = ee.Image(s1.filterDate(NOW.advance(-60, 'day'), NOW).sort('system:time_start', false).first());
var s1Date = ee.Date(s1Dernier.get('system:time_start'));
var orbite = s1Dernier.get('relativeOrbitNumber_start');
var s1Orbite = s1.filter(ee.Filter.eq('relativeOrbitNumber_start', orbite));
var lisse = function (im) { return im.focal_median(30, 'circle', 'meters'); };
var vvApres = lisse(s1Orbite.filterDate(s1Date.advance(-1, 'day'), s1Date.advance(1, 'day')).mosaic());
// Référence sèche : même orbite, juin à août, depuis 2023
var vvRef = lisse(s1Orbite.filterDate(REF_DEBUT, NOW).filter(ee.Filter.calendarRange(6, 8, 'month')).median());
var eau = vvApres.lt(P.eauVV).and(vvApres.subtract(vvRef).lt(-P.baisse))
  .and(gsw.lt(P.eauPermanente)).and(pente.lt(P.penteMaxEau)).and(hand.lt(P.handMaxEau)).selfMask();
eau = eau.updateMask(eau.connectedPixelCount(50, true).gte(P.pixelsMin)).clip(COMMUNE).rename('eau');

// ---------- Érosion : Sentinel-2 (optique) ----------
var cs = ee.ImageCollection('GOOGLE/CLOUD_SCORE_PLUS/V1/S2_HARMONIZED');
var s2 = ee.ImageCollection('COPERNICUS/S2_SR_HARMONIZED').filterBounds(COMMUNE)
  .linkCollection(cs, ['cs_cdf'])
  .map(function (im) { return im.updateMask(im.select('cs_cdf').gte(0.6)).select(['B2', 'B3', 'B4', 'B8', 'B11']).divide(10000)
    .copyProperties(im, ['system:time_start']); });
var indices = function (im) {
  var ndvi = im.normalizedDifference(['B8', 'B4']).rename('ndvi');
  var bsi = im.expression('((S+R)-(N+B))/((S+R)+(N+B))', {S: im.select('B11'), R: im.select('B4'), N: im.select('B8'), B: im.select('B2')}).rename('bsi');
  return im.addBands([ndvi, bsi]);
};
var s2Recent = indices(s2.filterDate(NOW.advance(-90, 'day'), NOW).median());
var s2Ref = indices(s2.filterDate(NOW.advance(-455, 'day'), NOW.advance(-365, 'day')).median());
var s2Clair = ee.Image(ee.ImageCollection('COPERNICUS/S2_SR_HARMONIZED').filterBounds(COMMUNE)
  .filterDate(NOW.advance(-120, 'day'), NOW).filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 30))
  .sort('system:time_start', false).first());
var solNu = s2Ref.select('ndvi').gt(P.ndviAvant).and(s2Recent.select('ndvi').lt(P.ndviApres))
  .and(s2Recent.select('bsi').gt(P.bsiApres)).and(pente.gte(P.penteMinErosion)).selfMask();
solNu = solNu.updateMask(solNu.connectedPixelCount(50, true).gte(P.pixelsMin)).clip(COMMUNE).rename('solnu');

// ---------- Interface ----------
var vis = {
  vv: {min: -25, max: 0, palette: ['000000', 'ffffff']},
  rgb: {bands: ['B4', 'B3', 'B2'], min: 0.02, max: 0.25, gamma: 1.2},
  rgbL1: {bands: ['B4', 'B3', 'B2'], min: 200, max: 2500, gamma: 1.2}
};
var gauche = ui.Map(), droite = ui.Map();
[gauche, droite].forEach(function (m) { m.setOptions('HYBRID'); m.setControlVisibility({layerList: true, zoomControl: true, mapTypeControl: false, fullscreenControl: false}); });
ui.Map.Linker([gauche, droite]);
var split = ui.SplitPanel({firstPanel: gauche, secondPanel: droite, wipe: true, style: {stretch: 'both'}});
var contour = ee.Image().paint(COMMUNE, 0, 3).visualize({palette: ['ffd43b']});

var titreG = ui.Label('', {position: 'top-left', fontWeight: 'bold', backgroundColor: 'ffffffcc'});
var titreD = ui.Label('', {position: 'top-right', fontWeight: 'bold', backgroundColor: 'ffffffcc'});
gauche.add(titreG); droite.add(titreD);

var panneau = ui.Panel({style: {width: '330px', padding: '8px'}});
var lbl = function (t, s) { return ui.Label(t, s || {}); };
panneau.add(lbl('UrbanRisk Mont-Ngafula', {fontSize: '20px', fontWeight: 'bold', color: '0A2A66'}));
panneau.add(lbl('Suivi satellite des inondations et de l\'érosion – BEGCED', {fontSize: '13px', color: '55627A'}));
var mode = ui.Select({items: ['Inondation (radar Sentinel-1)', 'Érosion et sol mis à nu (Sentinel-2)'], value: 'Inondation (radar Sentinel-1)', style: {stretch: 'horizontal'}});
panneau.add(mode);
var infoDates = lbl('Recherche des dernières images…', {fontSize: '13px', whiteSpace: 'pre'});
var infoStats = lbl('', {fontSize: '13px', whiteSpace: 'pre'});
panneau.add(infoDates); panneau.add(infoStats);
var btnBat = ui.Button({label: 'Compter les bâtiments touchés', style: {stretch: 'horizontal'}});
var infoBat = lbl('', {fontSize: '13px', whiteSpace: 'pre'});
panneau.add(btnBat); panneau.add(infoBat);
var btnZones = ui.Button({label: 'Zones à vérifier sur le terrain', style: {stretch: 'horizontal'}});
var infoZones = ui.Panel();
panneau.add(btnZones); panneau.add(infoZones);
panneau.add(lbl('Transparence des images radar / Sentinel', {fontSize: '12px', margin: '8px 8px 0 8px'}));
var opacite = ui.Slider({min: 0, max: 1, value: 1, step: 0.05, style: {stretch: 'horizontal'}});
panneau.add(opacite);
var noteZoom = lbl('Au zoom rapproché, l\'image satellite haute résolution (Google) s\'affiche sous les détections pour voir les maisons.', {fontSize: '12px', color: '55627A'});
panneau.add(noteZoom);
var legende = ui.Panel();
panneau.add(lbl('Légende', {fontWeight: 'bold', margin: '10px 0 2px 8px'})); panneau.add(legende);
var clic = lbl('Cliquez sur la carte pour connaître la valeur en un point.', {fontSize: '12px', color: '55627A', whiteSpace: 'pre'});
panneau.add(clic);
panneau.add(lbl('Faites glisser la séparation au milieu de la carte : à gauche l\'image de référence, à droite la plus récente.', {fontSize: '12px', color: '55627A'}));
panneau.add(lbl('Détection automatique non validée : à confirmer sur le terrain. Ce n\'est pas une alerte officielle.', {fontSize: '12px', color: 'B3261E'}));
panneau.add(lbl('Retour au site BEGCED', {fontSize: '12px'}, 'https://begced.com/diagnostic-parcelle.html').setUrl('https://begced.com/diagnostic-parcelle.html'));

var carreau = function (couleur, texte) {
  return ui.Panel([ui.Label('', {backgroundColor: couleur, padding: '7px', margin: '2px 6px 2px 8px'}), ui.Label(texte, {fontSize: '12px', margin: '2px'})], ui.Panel.Layout.flow('horizontal'));
};

function afficher() {
  gauche.layers().reset(); droite.layers().reset(); legende.clear(); infoBat.setValue(''); infoZones.clear();
  if (mode.getValue().indexOf('Inondation') === 0) {
    gauche.addLayer(vvRef.clip(ZONE), vis.vv, 'Radar de référence (saison sèche)');
    droite.addLayer(vvApres.clip(ZONE), vis.vv, 'Radar le plus récent');
    droite.addLayer(eau, {palette: ['00b4ff']}, 'Eau anormale détectée');
    legende.add(carreau('#00b4ff', 'Eau anormale détectée (inondation possible)'));
    legende.add(carreau('#000000', 'Radar sombre = surface lisse ou eau'));
    titreG.setValue('Référence : saisons sèches (juin–août) depuis 2023');
    s1Date.format('dd/MM/YYYY').evaluate(function (d) { titreD.setValue('Radar du ' + d); });
    btnBat.setLabel('Compter les bâtiments dans l\'eau détectée');
  } else {
    gauche.addLayer(s2Ref.clip(ZONE), vis.rgb, 'Image de référence (il y a un an)');
    droite.addLayer(s2Recent.clip(ZONE), vis.rgb, 'Image récente (90 derniers jours)');
    droite.addLayer(solNu, {palette: ['ff3b30']}, 'Sol mis à nu sur pente');
    legende.add(carreau('#ff3b30', 'Végétation disparue, sol nu sur pente ≥ 8° (ravinement ou terrassement possible)'));
    titreG.setValue('Il y a un an (médiane sans nuages)');
    titreD.setValue('90 derniers jours (médiane sans nuages)');
    btnBat.setLabel('Compter les bâtiments près du sol mis à nu');
  }
  [gauche, droite].forEach(function (m) { m.addLayer(contour, {}, 'Limite de Mont-Ngafula'); });
  appliquerOpacite();
}
mode.onChange(afficher);
// Couches d'image (radar ou Sentinel-2) : indices 0 à gauche et 0 à droite. Au-delà du zoom 15, elles s'effacent.
function appliquerOpacite() {
  var z = droite.getZoom();
  var o = z >= 15 ? 0 : opacite.getValue();
  [gauche, droite].forEach(function (m) { var l = m.layers(); if (l.length() > 0) l.get(0).setOpacity(o); });
}
opacite.onChange(appliquerOpacite);
droite.onChangeZoom(appliquerOpacite);

// Dates et surfaces
ee.Dictionary({
  s1: s1Date.format('dd/MM/YYYY HH:mm'),
  s2: ee.Algorithms.If(s2Clair, ee.Date(ee.Image(s2Clair).get('system:time_start')).format('dd/MM/YYYY'), 'aucune récente'),
  eauHa: eau.multiply(ee.Image.pixelArea()).reduceRegion({reducer: ee.Reducer.sum(), geometry: COMMUNE, scale: 10, maxPixels: 1e10, tileScale: 4}).get('eau'),
  solHa: solNu.multiply(ee.Image.pixelArea()).reduceRegion({reducer: ee.Reducer.sum(), geometry: COMMUNE, scale: 10, maxPixels: 1e10, tileScale: 4}).get('solnu')
}).evaluate(function (r, err) {
  if (err) { infoDates.setValue('Erreur de calcul : ' + err); return; }
  infoDates.setValue('Dernière image radar (Sentinel-1) : ' + r.s1 + ' UTC\nDernière image optique peu nuageuse (Sentinel-2) : ' + r.s2);
  infoStats.setValue('Eau anormale détectée : ' + ((r.eauHa || 0) / 1e4).toFixed(1) + ' ha\nSol mis à nu sur pente (sur un an) : ' + ((r.solHa || 0) / 1e4).toFixed(1) + ' ha');
});

btnBat.onClick(function () {
  infoBat.setValue('Calcul en cours…');
  var inond = mode.getValue().indexOf('Inondation') === 0;
  var masque = inond ? eau : solNu.focal_max(20, 'circle', 'meters');
  var zones = masque.reduceToVectors({geometry: COMMUNE, scale: 10, maxPixels: 1e10, geometryType: 'polygon', eightConnected: true, tileScale: 4});
  batiments.filterBounds(zones.geometry(10)).size().evaluate(function (n, err) {
    if (err) { infoBat.setValue('Calcul impossible (zone trop grande) : ' + err); return; }
    infoBat.setValue(n + ' bâtiments cartographiés (Open Buildings v3, 2023) ' + (inond ? 'touchent l\'eau détectée.' : 'sont à moins de 20 m du sol mis à nu.') + '\nPotentiellement exposés, non observés : à vérifier sur le terrain.');
  });
});

// Liste des zones détectées, pour la vérification de terrain (KoboCollect, GPS)
var zonesListe = [], zoneIdx = 0;
btnZones.onClick(function () {
  infoZones.clear(); infoZones.add(lbl('Calcul des zones…', {fontSize: '12px'}));
  var inond = mode.getValue().indexOf('Inondation') === 0;
  var masque = inond ? eau : solNu;
  var zones = masque.reduceToVectors({geometry: COMMUNE, scale: 10, maxPixels: 1e10, geometryType: 'polygon', eightConnected: true, tileScale: 4})
    .map(function (f) {
      var c = f.geometry().centroid(1).coordinates();
      return ee.Feature(f.geometry().centroid(1), {
        type: inond ? 'eau anormale (radar)' : 'sol mis a nu sur pente',
        surface_m2: f.geometry().area(1).round(),
        latitude: ee.Number(c.get(1)).multiply(1e5).round().divide(1e5),
        longitude: ee.Number(c.get(0)).multiply(1e5).round().divide(1e5),
        image_du: inond ? s1Date.format('YYYY-MM-dd') : NOW.format('YYYY-MM-dd')
      });
    }).sort('surface_m2', false).limit(50);
  var url = zones.getDownloadURL({format: 'csv', selectors: ['type', 'latitude', 'longitude', 'surface_m2', 'image_du'], filename: inond ? 'UrbanRisk_zones_eau' : 'UrbanRisk_zones_erosion'});
  zones.reduceColumns(ee.Reducer.toList(3), ['latitude', 'longitude', 'surface_m2']).get('list').evaluate(function (l, err) {
    infoZones.clear();
    if (err) { infoZones.add(lbl('Calcul impossible : ' + err, {fontSize: '12px'})); return; }
    zonesListe = l || []; zoneIdx = 0;
    if (!zonesListe.length) { infoZones.add(lbl('Aucune zone détectée sur la dernière image.', {fontSize: '12px'})); return; }
    infoZones.add(lbl(zonesListe.length + ' zones (les plus grandes d\'abord). Coordonnées à charger dans KoboCollect ou un GPS :', {fontSize: '12px'}));
    infoZones.add(ui.Label('Télécharger la liste (CSV)', {fontSize: '12px'}).setUrl(url));
    var txt = zonesListe.slice(0, 12).map(function (z, i) { return (i + 1) + '. ' + z[0] + ', ' + z[1] + ' – ' + Math.round(z[2]) + ' m²'; }).join('\n');
    infoZones.add(lbl(txt, {fontSize: '12px', whiteSpace: 'pre', fontFamily: 'monospace'}));
    var suiv = ui.Button({label: 'Aller à la zone suivante', style: {stretch: 'horizontal'}});
    suiv.onClick(function () {
      var z = zonesListe[zoneIdx % zonesListe.length]; zoneIdx++;
      droite.setCenter(z[1], z[0], 17);
      suiv.setLabel('Zone ' + zoneIdx + '/' + zonesListe.length + ' – aller à la suivante');
    });
    infoZones.add(suiv);
  });
});

droite.onClick(montrer); gauche.onClick(montrer);
function montrer(c) {
  var pt = ee.Geometry.Point([c.lon, c.lat]);
  clic.setValue('Point ' + c.lat.toFixed(5) + ', ' + c.lon.toFixed(5) + ' : calcul…');
  ee.Image.cat([vvRef.rename('vvRef'), vvApres.rename('vvApres'), eau.unmask(0), solNu.unmask(0), pente.rename('pente'),
    s2Ref.select('ndvi').rename('ndviRef'), s2Recent.select('ndvi').rename('ndviRecent')])
    .reduceRegion({reducer: ee.Reducer.first(), geometry: pt, scale: 10}).evaluate(function (v) {
      if (!v) return;
      var f = function (x, d) { return x === null || x === undefined ? 'indisponible' : x.toFixed(d); };
      clic.setValue('Point ' + c.lat.toFixed(5) + ', ' + c.lon.toFixed(5) +
        '\nRadar : ' + f(v.vvRef, 1) + ' dB → ' + f(v.vvApres, 1) + ' dB' + (v.eau ? '  → EAU DÉTECTÉE' : '') +
        '\nVégétation (NDVI) : ' + f(v.ndviRef, 2) + ' → ' + f(v.ndviRecent, 2) + (v.solnu ? '  → SOL MIS À NU' : '') +
        '\nPente : ' + f(v.pente, 1) + '°');
    });
}

ui.root.clear();
ui.root.add(ui.Panel([panneau, split], ui.Panel.Layout.flow('horizontal'), {stretch: 'both'}));
gauche.centerObject(COMMUNE, 11);
afficher();
