/* UrbanRisk Mont-Ngafula – bandeau de vigilance automatique (BEGCED)
   Relit la prévision GFS + ECMWF (Open-Meteo) à chaque visite et applique la méthode UrbanRisk v0.2.
   Vigilance expérimentale : ce n'est pas une alerte officielle. */
(function () {
  "use strict";
  var LIEN = "/diagnostic-parcelle";
  var SEUILS = [20, 50, 80], NOMS = ["aucune", "jaune", "orange", "rouge"];
  // Centres des 3 bassins pilotes + 2 points de contrôle (nord et sud de la commune)
  var PTS = [
    {nom: "Bassin B1 (centre)", lat: -4.4621, lon: 15.2622, rav: 9331, r: {50: 13, 100: 165, 150: 272}, d: {50: 4, 100: 10, 150: 30}},
    {nom: "Bassin B2 (est)", lat: -4.4759, lon: 15.3841, rav: 206, r: {50: 0, 100: 25, 150: 36}, d: {50: 0, 100: 1, 150: 4}},
    {nom: "Bassin B3 (ouest)", lat: -4.5164, lon: 15.2097, rav: 932, r: {50: 0, 100: 8, 150: 8}, d: {50: 0, 100: 0, 150: 1}},
    {nom: "Nord de la commune", lat: -4.4000, lon: 15.2100},
    {nom: "Sud de la commune", lat: -4.5800, lon: 15.3300}
  ];
  var interp = function (t, P) {
    if (!t) return 0;
    var x = [0, 50, 100, 150], y = [0, t[50], t[100], t[150]];
    if (P >= 150) return y[3];
    for (var i = 0; i < 3; i++) if (P <= x[i + 1]) return y[i] + (P - x[i]) / 50 * (y[i + 1] - y[i]);
  };
  var niveauPluie = function (P) { return P >= SEUILS[2] ? 3 : P >= SEUILS[1] ? 2 : P >= SEUILS[0] ? 1 : 0; };
  // Niveau de diffusion publique (site, WhatsApp, e-mail) : pluie seule, sur 72 h ou sur la journée la plus pluvieuse
  var niveauDiffusion = function (P, J) { return Math.max(P >= 80 ? 3 : P >= 50 ? 2 : P >= 20 ? 1 : 0, J >= 50 ? 3 : J >= 35 ? 2 : J >= 20 ? 1 : 0); };
  function vigilance(p, P) {
    var n = niveauPluie(P);
    if (!p.r) return n;
    var enjeux = interp(p.r, P) >= 50 || interp(p.d, P) >= 10 || (P >= 30 && p.rav >= 2000);
    return n > 0 && enjeux ? Math.min(3, n + 1) : n;
  }
  var fmtJour = function (ms) { return new Date(ms).toLocaleDateString("fr-FR", {timeZone: "Africa/Kinshasa", weekday: "long", day: "2-digit", month: "2-digit"}); };
  var fmtH = function (ms) { return new Date(ms).toLocaleString("fr-FR", {timeZone: "Africa/Kinshasa", weekday: "short", day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit"}); };
  var nf = function (x) { return Math.round(x).toLocaleString("fr-FR"); };

  function analyser(lst) {
    var now = Date.now(), res = [];
    lst.forEach(function (loc, i) {
      var t = loc.hourly.time.map(function (s) { return Date.parse(s + ":00Z"); });
      var mods = ["gfs_seamless", "ecmwf_ifs025"], best = null;
      mods.forEach(function (m) {
        var a = loc.hourly["precipitation_" + m] || [], futur = 0, passe = 0, jours = {}, n = 0;
        for (var k = 0; k < a.length; k++) {
          var v = a[k]; if (v == null) continue;
          var dt = t[k] - now;
          if (dt >= 0 && dt < 72 * 3600e3) {
            futur += v; n++;
            var j = new Date(t[k] + 3600e3).toISOString().slice(0, 10); // jour de Kinshasa (UTC+1)
            jours[j] = (jours[j] || 0) + v;
          } else if (dt < 0 && dt >= -24 * 3600e3) passe += v;
        }
        if (n < 60) return;
        var jMax = Object.keys(jours).sort(function (x, y) { return jours[y] - jours[x]; })[0];
        var o = {modele: m, P: futur, passe: passe, jour: jMax, pluieJour: jours[jMax] || 0};
        if (!best || o.P > best.P) best = o;
      });
      if (best) { best.pt = PTS[i]; best.vig = vigilance(PTS[i], best.P); best.diff = niveauDiffusion(best.P, best.pluieJour); res.push(best); }
    });
    return res;
  }

  function afficher(res, surPageUrbanRisk) {
    if (!res.length) return;
    // Même règle partout : niveau de diffusion publique (la carte garde la vigilance par bassin).
    res.forEach(function (r) { r.niv = r.diff; });
    var max = Math.max.apply(null, res.map(function (r) { return r.niv; }));
    if (max < 2) return; // bandeau seulement à partir de l'orange
    var zones = res.filter(function (r) { return r.niv >= Math.max(1, max - 1); }).sort(function (a, b) { return b.niv - a.niv || b.P - a.P; });
    var top = zones[0], Pmax = Math.max.apply(null, res.map(function (r) { return r.P; }));
    var passeMax = Math.max.apply(null, res.map(function (r) { return r.passe; }));
    var jourTxt = top.jour ? fmtJour(Date.parse(top.jour + "T12:00:00Z")) : "";
    var couleurs = {1: ["#FFF6C2", "#6B5800", "#E0C200"], 2: ["#FFE7CC", "#8A4300", "#F08A00"], 3: ["#FDE1DE", "#9B1C14", "#D93025"]}[max];
    var el = document.getElementById("ur-alerte");
    if (!el) {
      var box = document.createElement("div"); box.style.cssText = "padding:0 16px";
      el = document.createElement("div"); el.id = "ur-alerte"; box.appendChild(el);
      var main = document.querySelector("main") || document.body.firstElementChild;
      main.parentNode.insertBefore(box, main);
    }
    el.setAttribute("role", "alert");
    el.style.cssText = "margin:12px auto;max-width:1240px;padding:12px 16px;border-radius:12px;border:2px solid " + couleurs[2] + ";background:" + couleurs[0] + ";color:" + couleurs[1] + ";font-family:'Source Sans 3','Segoe UI',system-ui,sans-serif;font-size:15px;line-height:1.45";
    var conseils = max >= 2
      ? "Évitez les ravines, les fonds de vallée et le bord des rivières ; ne traversez pas un cours d'eau en crue ; dégagez les caniveaux ; mettez documents et biens de valeur à l'abri ; suivez les consignes des autorités."
      : "Restez attentifs aux prochaines mises à jour et dégagez les caniveaux autour de chez vous.";
    el.innerHTML = "<strong style='font-size:16px'>⚠️ Vigilance expérimentale " + NOMS[max].toUpperCase() + " – Mont-Ngafula (Kinshasa)</strong><br>" +
      "Jusqu'à <b>" + nf(Pmax) + " mm</b> de pluie prévus d'ici le " + fmtH(Date.now() + 72 * 3600e3) + (jourTxt ? " ; journée la plus pluvieuse : <b>" + jourTxt + "</b> (≈ " + nf(top.pluieJour) + " mm)" : "") + ".<br>" +
      "Zones concernées : " + zones.map(function (z) { return z.pt.nom + " (" + NOMS[z.niv] + ")"; }).join(", ") + ".<br>" +
      (passeMax >= 10 ? "Pluie estimée des dernières 24 h : jusqu'à " + nf(passeMax) + " mm.<br>" : "") +
      "<em>" + conseils + "</em><br>" +
      "<span style='font-size:13px'>Prévision GFS / ECMWF lue le " + fmtH(Date.now()) + " (scénario prudent : modèle le plus pluvieux). Information BEGCED expérimentale, non officielle. " +
      (surPageUrbanRisk ? "" : "<a href='" + LIEN + "' style='color:inherit;font-weight:700'>Voir la carte UrbanRisk</a>") + "</span>";
  }

  var url = "https://api.open-meteo.com/v1/forecast?latitude=" + PTS.map(function (p) { return p.lat; }).join(",") +
    "&longitude=" + PTS.map(function (p) { return p.lon; }).join(",") +
    "&hourly=precipitation&models=gfs_seamless,ecmwf_ifs025&past_days=1&forecast_days=4&timezone=GMT";
  fetch(url).then(function (r) { if (!r.ok) throw 0; return r.json(); }).then(function (j) {
    afficher(analyser(Array.isArray(j) ? j : [j]), /diagnostic-parcelle/.test(location.pathname));
  }).catch(function () { /* service indisponible : aucun bandeau, aucune fausse alerte */ });
})();
