/* =====================================================================
   BEGCED — PORTFOLIO (projets et réalisations)
   ---------------------------------------------------------------------
   Le portfolio est volontairement VIDE au lancement : n'ajoutez que
   des missions réellement réalisées par BEGCED.

   AJOUTER UN PROJET :
   1. Copiez le modèle ci-dessous (entre /* et *\/), collez-le dans
      la liste « projets », puis remplissez les champs.
   2. Mettez les images dans  assets/img/projets/
   3. « domaine » doit être l'un de :
      "environnement", "geomatique", "genie-civil", "numerique", "formation"
   4. « client » : laissez "" si sa publication n'est pas autorisée.
   ===================================================================== */
window.BEGCED_PROJETS = [
  /*  ----- MODÈLE À COPIER -----
  {
    titre: "Nom du projet",
    domaine: "geomatique",
    client: "",                       // seulement si la publication est autorisée
    lieu: "Province, RDC",
    date: "Mois Année",
    contexte: "Pourquoi ce projet ?",
    intervention: "Ce que BEGCED a réalisé.",
    resultats: "Les résultats concrets obtenus.",
    outils: ["QGIS", "KoboCollect"],
    images: [
      { src: "assets/img/projets/mon-projet-1.jpg", alt: "Description de l'image" }
    ]
  },
  */
];
