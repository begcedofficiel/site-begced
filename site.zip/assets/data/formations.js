/* =====================================================================
   BEGCED — FORMATIONS
   ---------------------------------------------------------------------
   Les objectifs et compétences ci-dessous sont des PROPOSITIONS de
   rédaction : faites-les valider par le département Recherche et
   formation avant publication.
   « niveau », « dates » et « modalites » restent "" tant qu'ils ne
   sont pas confirmés : le site affiche alors « À communiquer ».
   N'indiquez ni tarif ni certification non confirmés.
   ===================================================================== */
window.BEGCED_FORMATIONS = [
  {
    id: "sig-qgis-arcgis-gee",
    icone: "map",
    titre: "QGIS, ArcGIS et Google Earth Engine",
    description: "Prendre en main les principaux logiciels de SIG et la plateforme Google Earth Engine pour produire, analyser et diffuser des données géographiques.",
    niveau: "",
    objectifs: ["Organiser un projet SIG et ses données", "Produire des cartes thématiques de qualité", "Traiter des images satellitaires dans Google Earth Engine"],
    competences: ["Gestion de couches vectorielles et raster", "Mise en page cartographique", "Scripts de base dans Google Earth Engine"],
    dates: "", modalites: ""
  },
  {
    id: "kobocollect",
    icone: "phoneapp",
    titre: "KoboCollect et collecte numérique de données",
    description: "Concevoir des formulaires numériques et organiser des enquêtes de terrain fiables sur téléphone ou tablette.",
    niveau: "",
    objectifs: ["Concevoir un formulaire XLSForm", "Déployer une enquête et suivre la collecte", "Exporter et contrôler la qualité des données"],
    competences: ["Conception de questionnaires", "Collecte géoréférencée", "Nettoyage et export des données"],
    dates: "", modalites: ""
  },
  {
    id: "analyse-spatiale-teledetection",
    icone: "layers",
    titre: "Analyse spatiale, cartographie et télédétection",
    description: "Comprendre et appliquer les méthodes d’analyse spatiale et de télédétection aux questions territoriales et environnementales.",
    niveau: "",
    objectifs: ["Choisir les données et méthodes adaptées", "Classer l’occupation du sol", "Détecter et cartographier des changements"],
    competences: ["Prétraitement d’images", "Classification et validation", "Analyse de changements"],
    dates: "", modalites: ""
  },
  {
    id: "r-python-donnees",
    icone: "bars",
    titre: "R, RStudio et Python appliqués aux données environnementales et géographiques",
    description: "Automatiser le traitement, l’analyse statistique et la visualisation de données environnementales et spatiales.",
    niveau: "",
    objectifs: ["Importer, nettoyer et structurer des données", "Réaliser des analyses statistiques reproductibles", "Produire graphiques et cartes par le code"],
    competences: ["Programmation de base en R et Python", "Analyse de données", "Visualisation et rapports reproductibles"],
    dates: "", modalites: ""
  },
  {
    id: "biomasse-carbone-climat",
    icone: "leaf",
    titre: "Calcul de biomasse, carbone et analyse climatique",
    description: "Estimer la biomasse et les stocks de carbone à partir d’inventaires, et analyser les variables climatiques.",
    niveau: "",
    objectifs: ["Organiser un inventaire forestier", "Appliquer des équations allométriques", "Analyser des séries climatiques"],
    competences: ["Calcul de biomasse et de carbone", "Estimation des émissions de CO₂", "Analyse de données climatiques"],
    dates: "", modalites: ""
  },
  {
    id: "modelisation-3d",
    icone: "cube",
    titre: "ArchiCAD, Revit, SketchUp et outils de modélisation",
    description: "Concevoir des plans et des maquettes numériques 2D/3D de bâtiments et d’infrastructures.",
    niveau: "",
    objectifs: ["Dessiner des plans techniques", "Construire une maquette 3D", "Comprendre les principes du BIM"],
    competences: ["Modélisation 2D/3D", "Production de plans", "Échanges de maquettes numériques"],
    dates: "", modalites: ""
  },
  {
    id: "web-applications-ia",
    icone: "code",
    titre: "Développement web, applications et initiation à l’intelligence artificielle",
    description: "Découvrir la création de sites et d’applications, et les bases de l’intelligence artificielle appliquée aux données.",
    niveau: "",
    objectifs: ["Créer une page web simple", "Comprendre l’architecture d’une application", "Découvrir les usages de l’IA (classification, prédiction)"],
    competences: ["HTML, CSS et notions de programmation", "Logique applicative", "Premiers modèles d’apprentissage automatique"],
    dates: "", modalites: ""
  }
];
